#!/usr/bin/env python3
"""Replace the footer's [MONTH YEAR] placeholder with the deploy date.

Run by .github/workflows/deploy.yml against the runner's checkout, so the
committed files keep the placeholder and only the published site carries a
date. That means the date shown always reflects when the site was actually
deployed, and no bot commit is ever pushed back to the repo.

Usage:  python3 .github/scripts/stamp-date.py "September 2026" [root]

Exits non-zero if the placeholder is missing from every HTML file, so a
future rename of the footer fails the deploy loudly instead of silently
publishing an unstamped footer.
"""
import glob
import io
import os
import sys

PLACEHOLDER = "Updated [MONTH YEAR]"


def main():
    if len(sys.argv) < 2 or not sys.argv[1].strip():
        sys.exit("usage: stamp-date.py '<Month Year>' [root]")

    stamp = sys.argv[1].strip()
    root = sys.argv[2] if len(sys.argv) > 2 else "."
    replacement = "Updated " + stamp

    total = 0
    for path in sorted(glob.glob(os.path.join(root, "*.html"))):
        text = io.open(path, encoding="utf-8").read()
        count = text.count(PLACEHOLDER)
        if not count:
            continue
        io.open(path, "w", encoding="utf-8").write(
            text.replace(PLACEHOLDER, replacement)
        )
        total += count
        print("  %-12s %d occurrence%s -> %s"
              % (os.path.basename(path), count, "" if count == 1 else "s", replacement))

    if not total:
        sys.exit(
            "ERROR: no HTML file under %r contains %r.\n"
            "The footer markup probably changed. Update PLACEHOLDER in "
            ".github/scripts/stamp-date.py to match, or the published site "
            "will show an unstamped footer." % (root, PLACEHOLDER)
        )

    print("Stamped %d footer%s with %r."
          % (total, "" if total == 1 else "s", stamp))


if __name__ == "__main__":
    main()
